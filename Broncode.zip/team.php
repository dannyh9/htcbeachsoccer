<?php 
include 'header.php';
include 'databaseconnection.php';
?>
<body>
    <div class="container">
        <div class="row product">
            <div class="col-md-5 col-md-offset-0"><img class="img-responsive" src="assets/img/suit_jacket.jpg"></div>
            <div class="col-md-7">
                <h2>Suit Jacket</h2>
                <p>Sed mollis, urna eu tempus facilisis, diam tellus aliquam tortor, et vestibulum ante quam non justo. Nullam luctus rutrum mattis. Maecenas in pharetra mi, vel mollis odio. Morbi non mauris massa. </p>
            </div>
        </div>
        <div class="page-header"></div>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Column 1</th>
                        <th>Column 2</th>
                        <th>Column 3</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Cell</td>
                        <td>Cell</td>
                        <td>Cell</td>
                    </tr>
                    <tr>
                        <td>Cell</td>
                        <td>Cell</td>
                        <td>Cell</td>
                    </tr>
                    <tr>
                        <td>Cell</td>
                        <td>Cell</td>
                        <td>Cell</td>
                    </tr>
                    <tr>
                        <td>Cell</td>
                        <td>Cell</td>
                        <td>Cell</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
  </div>
  </body>
<?php 
include 'right-menu.php';
include 'footer.php';
?>
 